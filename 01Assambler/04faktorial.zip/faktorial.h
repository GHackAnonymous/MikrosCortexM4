#ifndef FAKT_H
#define FAKT_H

#include <stdint.h>

uint32_t factorial(uint32_t n);

#endif
