#ifndef SUM_H
#define SUM_H

int sum(int n, int m);

#endif
