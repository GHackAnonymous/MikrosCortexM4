int x1=7, x2=3, x3=45, x4=11, result;

int main()
{
	result=x1-x2+x3-x4;
	while(1){}
}
